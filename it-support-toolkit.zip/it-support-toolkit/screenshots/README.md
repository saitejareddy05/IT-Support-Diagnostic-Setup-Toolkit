# Screenshots

Put your own evidence here. Suggested file names (the main README refers to them):

| File | What to capture |
|------|-----------------|
| p1-report-top.png | Top of the DiagReport text file (OS, license, hardware) |
| p1-report-fsutil-boot.png | File system per drive + boot mode section |
| p1-repairs.png | DISM / SFC / CHKDSK output section |
| p2-new-user.png | `Get-LocalUser` + `net user` + Users group membership |
| p2-partition-before.png / p2-partition-after.png | Disk Management before and after |
| p2-update-pause.png | Settings > Windows Update showing "Paused until" |
| p2-restore-point.png | `Get-ComputerRestorePoint` output |
| p2-theme-settings.png / p2-theme-registry.png | Same change via Settings and via PowerShell |
| p2-security.png | Defender schedule (`Get-MpPreference`) or `manage-bde -status` |
| p3-static-ip.png | `Get-NetIPConfiguration` after the change |
| p3-firewall-blocked.png | `Test-NetConnection` True before, False after |
| p3-discovery.png | Network folder showing / not showing the PC |
| p3-share.png | `Get-SmbShare` + access from the other device |
| p3-netuse.png | `net use` output + mapped drive in Explorer |
| p3-rdp-ssh.png | RDP session and SSH session |
| p3-workgroup.png | `Win32_ComputerSystem` workgroup output |
| p4-*.png | One screenshot per Linux exercise |
| p5-*.png | Silent install, uninstall leftovers check, restriction test |
| p6-*.png | Sync conflict, view-only vs edit test |
