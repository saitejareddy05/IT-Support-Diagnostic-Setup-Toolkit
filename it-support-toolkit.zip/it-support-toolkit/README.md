# IT Support Diagnostic & Setup Toolkit

A hands-on toolkit built around a single scenario: you're a new IT support hire, and
your manager wants a diagnostic + setup toolkit any junior tech can run on a new or
problem machine, plus documentation of a full employee onboarding flow.

Every script here is meant to be **run by hand first**, read, understood, and only
then trusted — none of it is a black box. Each `.ps1` / `.sh` file has a comment
header explaining what it does and why.

## Quick start

```powershell
# Windows (elevated PowerShell)
cd windows-scripts
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\SysDiag.ps1 -SkipRepairs      # fast first run, then run without the switch
```
```bash
# WSL
cd linux-scripts && chmod +x *.sh && ./disk-check.sh ~
```

## Folder structure

```
.
├── windows-scripts/       Parts 1, 2, 3 (partly), 5 — PowerShell
├── linux-scripts/         Part 4 — Bash (WSL)
├── networking-notes/      Part 3 & 6 — write-up templates for the pieces that
│                          are exercises/comparisons rather than pure scripts
├── screenshots/           Your own evidence goes here (see screenshots/README.md)
├── index.html             Static viewer for this toolkit (for GitHub Pages/Vercel/Netlify)
├── netlify.toml            Netlify config (plain-text headers for the scripts)
└── vercel.json              Vercel config (same purpose)
```

## Requirements

- **Windows scripts:** Windows 10/11, PowerShell 5.1+ (built in), run **as
  Administrator** unless noted. If scripts are blocked, allow them for the current
  session only: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`.
  `P2-PartitionTestDisk.ps1` uses Hyper-V cmdlets when present and falls back to
  `diskpart` on Windows Home, so it works on both.
- **Linux scripts:** WSL2 with Ubuntu (or any Debian-based distro). Install with:
  ```powershell
  wsl --install
  ```
  then open "Ubuntu" from the Start menu and run `sudo apt update`.

---

## Part 1 — System Diagnostic Script

```powershell
cd windows-scripts
.\SysDiag.ps1              # full run, ~10-40 min (DISM/SFC/CHKDSK take most of that)
.\SysDiag.ps1 -SkipRepairs # quick report, skips DISM/SFC/CHKDSK
```
Or just double-click `Run-SysDiag.bat` — it elevates itself and runs the script.

Produces a timestamped report in `reports/` (git-ignored — it's specific to your
machine) covering: OS version/build/edition, license status, disk space, file system
type per drive (`fsutil fsinfo volumeinfo`), boot mode (UEFI vs Legacy BIOS, via
`bcdedit`), installed apps, network config, top 10 processes by memory, and the
DISM/SFC/CHKDSK repair output.

**Screenshot checklist:** `p1-report-top.png`, `p1-report-fsutil-boot.png`, `p1-repairs.png`

---

## Part 2 — New Employee Onboarding

| Script | What it does |
|---|---|
| `P2-NewUser.ps1` | Creates a local **standard** (non-admin) account |
| `P2-PartitionTestDisk.ps1` | Creates a practice **virtual disk** (not your real one!), initializes, partitions, formats NTFS — documents the shrink/diskpart equivalent too |
| `P2-UpdatePause.ps1` | Sets/clears the Windows Update pause policy via registry |
| `P2-RestorePoint.ps1` | Enables System Restore, creates + lists restore points |
| `P2-Theme.ps1` | Sets dark/light theme via registry — compare against Settings by hand |
| `P2-SecurityCheck.ps1` | Verifies Defender scan schedule / BitLocker status after you configure them via Control Panel |

```powershell
cd windows-scripts
.\P2-NewUser.ps1 -UserName jdoe -FullName "Jane Doe"
.\P2-PartitionTestDisk.ps1
.\P2-UpdatePause.ps1 -Days 7
.\P2-RestorePoint.ps1
.\P2-Theme.ps1 -Mode Dark          # then compare with Settings > Personalization > Colors
.\P2-SecurityCheck.ps1             # after enabling BitLocker / setting a Defender scan schedule by hand
```

**Security setting step (manual, do this first):** Control Panel > System and Security >
BitLocker Drive Encryption (enable on a drive), or Windows Security > Virus & threat
protection > Scan options (set a schedule) — then run `P2-SecurityCheck.ps1` to verify
from the command line.

**Screenshot checklist:** `p2-new-user.png`, `p2-partition-before.png` / `p2-partition-after.png`,
`p2-update-pause.png`, `p2-restore-point.png`, `p2-theme-settings.png` / `p2-theme-registry.png`, `p2-security.png`

---

## Part 3 — Networking Setup

| Script | What it does |
|---|---|
| `P3-StaticIP.ps1` | Sets a static IPv4 address/gateway/DNS on an adapter, or restores DHCP |
| `P3-FirewallTest.ps1` | Blocks a TCP port and proves it with `Test-NetConnection` before/after |
| `P3-NetworkDiscovery.ps1` | Sets Private/Public network category, checks the Network Discovery firewall rules |
| `P3-ShareFolder.ps1` | Shares a folder + sets matching NTFS permissions |
| `P3-MapDriveAndPrinter.ps1` | Maps a share as a drive letter (`net use`) and a network printer |
| `P3-WorkgroupInfo.ps1` | Shows/sets Workgroup name, explains Workgroup vs Domain |

```powershell
cd windows-scripts
.\P3-StaticIP.ps1 -InterfaceAlias "Ethernet 2" -IPAddress 192.168.1.50 -PrefixLength 24 -Gateway 192.168.1.1 -DNS 1.1.1.1,8.8.8.8
.\P3-FirewallTest.ps1 -Port 8080
.\P3-NetworkDiscovery.ps1 -Category Private
.\P3-ShareFolder.ps1 -Path C:\ShareTest -ShareName TeamDocs
.\P3-MapDriveAndPrinter.ps1 -SharePath \\SERVER\TeamDocs -DriveLetter Z
.\P3-WorkgroupInfo.ps1
```

RDP vs SSH vs TeamViewer/AnyDesk is a hands-on comparison exercise, not a single
script — steps and a fill-in comparison table are in
[`networking-notes/RDP-vs-RemoteTools.md`](networking-notes/RDP-vs-RemoteTools.md).
Firewall/discovery test results template:
[`networking-notes/Firewall-and-Discovery-Notes.md`](networking-notes/Firewall-and-Discovery-Notes.md).

**Screenshot checklist:** `p3-static-ip.png`, `p3-firewall-blocked.png`, `p3-discovery.png`,
`p3-share.png`, `p3-netuse.png`, `p3-rdp-ssh.png`, `p3-workgroup.png`

---

## Part 4 — Linux Health Check (WSL)

| Script | What it does |
|---|---|
| `disk-check.sh` | Disk usage, top 5 largest dirs/files, flags any filesystem >80% full |
| `backup.sh` | `tar.gz` backup of a folder with a timestamped filename |
| `setup-cron.sh` | Schedules `disk-check.sh` hourly via cron |
| `file-org-practice.sh` | Builds a messy test folder, then organizes it with `find`/`cp -r`/`mv`/`ls -la` |
| `permissions-practice.sh` | `chmod 750` demo, explained bit by bit, with a real switch-user test |
| `user-admin-practice.sh` | Creates a Linux user, adds to sudo/wheel group, verifies with `id`/`whoami` |
| `network-check.sh` | `ip a`, `ping`, `ss -tulpn`, `curl` connectivity test |
| `install-htop.sh` | Installs `htop` (apt/dnf/pacman) |

```bash
cd linux-scripts
chmod +x *.sh                       # exec bit may not survive download/clone — run this once
./disk-check.sh ~
./backup.sh ~/some-folder
./setup-cron.sh
./file-org-practice.sh
./permissions-practice.sh
sudo ./user-admin-practice.sh testuser
./network-check.sh https://example.com
./install-htop.sh
```

**Screenshot checklist:** one per exercise, e.g. `p4-disk-check.png`, `p4-cron.png`,
`p4-permissions.png`, `p4-user-admin.png`, `p4-network.png`, `p4-htop.png`

---

## Part 5 — Application Lifecycle

| Script | What it does |
|---|---|
| `P5-SilentInstall.ps1` | Silent install (`.msi`/`.exe`), verify via before/after snapshot, then full uninstall + leftover check |
| `P5-AppMinSpecs.ps1` | Compares an app's minimum requirements against this machine's specs (reuses Part 1's data) |
| `P5-RestrictedApp.ps1` | Denies a standard user access to an app's folder via NTFS ACL, with a `runas` test to prove it |

```powershell
cd windows-scripts
.\P5-SilentInstall.ps1 -InstallerPath C:\Downloads\7z-setup.exe -SilentArgs '/S' -Phase Install
.\P5-SilentInstall.ps1 -Phase Verify -DisplayNameFilter '7-Zip'
.\P5-SilentInstall.ps1 -Phase Uninstall -DisplayNameFilter '7-Zip'
.\P5-AppMinSpecs.ps1 -AppName "Example App" -MinRamGB 8 -MinDiskGB 20 -MinOSBuild 19045
.\P5-RestrictedApp.ps1 -FolderPath "C:\Program Files\ExampleApp" -UserName jdoe
```

Distribution-method comparison (installer `.exe`/`.msi` vs portable app — pros/cons)
is a written exercise: install the same kind of app both ways and note the differences
(admin rights needed, registry footprint, portability, auto-updates) in your own README
notes or `networking-notes/`.

**Screenshot checklist:** `p5-install.png`, `p5-uninstall-clean.png`, `p5-restriction-test.png`

---

## Part 6 — Cloud-Based Productivity Tools

Two hands-on exercises with a fill-in template:
[`networking-notes/Cloud-Tools-Notes.md`](networking-notes/Cloud-Tools-Notes.md) —
sync conflict resolution, view-only vs edit sharing, and Storage-as-a-Service vs
Software-as-a-Service.

**Screenshot checklist:** `p6-sync-conflict.png`, `p6-share-permissions.png`

---

## Deployment (this README + notes, as a browsable site)

The scripts themselves run locally on your machine — they are not meant to be "deployed."
What you *can* deploy is `index.html`, a static viewer for this repo (README + script
listing + your notes) so you have a shareable link for your manager/portfolio.

### GitHub

```bash
cd it-support-toolkit
git init
git add .
git commit -m "IT Support Diagnostic & Setup Toolkit"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

### Vercel

1. [vercel.com](https://vercel.com) → **Add New... > Project** → import the GitHub repo.
2. Framework preset: **Other** (no build step needed — it's static).
3. Deploy. `vercel.json` is already set up to serve the scripts/notes as readable
   plain text instead of triggering a download.

### Netlify

1. [app.netlify.com](https://app.netlify.com) → **Add new site > Import an existing project**
   → pick the GitHub repo.
2. Build command: leave blank. Publish directory: `.` (repo root).
3. Deploy. `netlify.toml` is already configured the same way as `vercel.json`.

Either platform auto-redeploys on every `git push` to `main`.

---

## Self-test

If you can answer these without looking anything up, you've actually learned the
material rather than just run the scripts:

1. Why does the diagnostic script avoid `Win32_Product` for listing installed apps?
2. What's the practical difference between the share permission and the NTFS
   permission on a shared folder, and which one wins when they disagree?
3. Why would SSH be the better choice over RDP or TeamViewer for managing ten
   Linux servers, but a bad choice for helping your grandmother fix her PC?
4. What does `chmod 750` actually grant to the owner, the group, and everyone else?
5. Why is Storage-as-a-Service (OneDrive) not the same thing as
   Software-as-a-Service (Google Docs), even though both "live in the cloud"?

If you get stuck on a specific error while running any of this, that's the point where
it's worth digging in — check the script's comment header first, then the relevant
Microsoft Learn / man page.
