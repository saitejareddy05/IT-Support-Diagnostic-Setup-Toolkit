<#
.SYNOPSIS
    Part 3 (Networking) - map a network share as a drive letter and (optionally) a printer.

.DESCRIPTION
    Wraps `net use` for a share and (optionally) `Add-Printer` for a shared network
    printer, then verifies both.

.PARAMETER SharePath
    UNC path, e.g. \\SERVER\TeamDocs

.PARAMETER DriveLetter
    Letter to map, e.g. Z

.PARAMETER PrinterPath
    Optional UNC path to a shared printer, e.g. \\SERVER\OfficePrinter

.EXAMPLE
    .\P3-MapDriveAndPrinter.ps1 -SharePath \\SERVER\TeamDocs -DriveLetter Z -PrinterPath \\SERVER\OfficePrinter
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string]$SharePath,
    [Parameter(Mandatory)] [ValidatePattern('^[A-Za-z]$')] [string]$DriveLetter,
    [string]$PrinterPath
)
. "$PSScriptRoot\_Common.ps1"

Write-Step "Mapping $SharePath as ${DriveLetter}:"
net use "${DriveLetter}:" $SharePath /persistent:yes
Write-Output ''
Write-Output 'PowerShell equivalent (for comparison):'
Write-Output "  New-PSDrive -Name $DriveLetter -PSProvider FileSystem -Root '$SharePath' -Persist"

if ($PrinterPath) {
    Write-Step "Mapping network printer $PrinterPath"
    try {
        Add-Printer -ConnectionName $PrinterPath
        Write-Ok 'Printer mapped.'
    }
    catch { Write-Warn "Add-Printer failed: $($_.Exception.Message)  (try: rundll32 printui.dll,PrintUIEntry /in /n `"$PrinterPath`")" }
}

Write-Step 'Verifying'
net use
Get-PSDrive -PSProvider FileSystem | Where-Object { $_.DisplayRoot } | Select-Object Name, DisplayRoot
if ($PrinterPath) { Get-Printer | Where-Object { $_.Name -like "*$PrinterPath*" -or $_.PortName -like "*$PrinterPath*" } }

Write-Output ''
Write-Output "To remove later:  net use ${DriveLetter}: /delete"
