@echo off
REM Double-click launcher for junior techs: asks for admin rights, then runs SysDiag.ps1.
REM Add -SkipRepairs after the script name for a quick report.
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0SysDiag.ps1" %*
echo.
pause
