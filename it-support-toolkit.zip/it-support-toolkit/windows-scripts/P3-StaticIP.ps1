<#
.SYNOPSIS
    Part 3 (Networking) - set/restore a static IPv4 address, gateway and DNS.

.DESCRIPTION
    Backs up the adapter's current config to JSON, then applies a static IP. Run again
    with -Restore to switch the adapter back to DHCP. ALWAYS test this on a lab/VM
    adapter, not on the connection you're using for this SSH/RDP session, unless you
    like locking yourself out.

.PARAMETER InterfaceAlias
    Adapter name, e.g. "Ethernet" or "Ethernet 2". See: Get-NetAdapter

.EXAMPLE
    .\P3-StaticIP.ps1 -InterfaceAlias "Ethernet 2" -IPAddress 192.168.1.50 -PrefixLength 24 -Gateway 192.168.1.1 -DNS 1.1.1.1,8.8.8.8
.EXAMPLE
    .\P3-StaticIP.ps1 -InterfaceAlias "Ethernet 2" -Restore
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string]$InterfaceAlias,
    [string]$IPAddress,
    [int]$PrefixLength = 24,
    [string]$Gateway,
    [string[]]$DNS,
    [switch]$Restore
)
. "$PSScriptRoot\_Common.ps1"
Assert-Admin

$backupFile = Join-Path $PSScriptRoot "..\reports\netbackup_$($InterfaceAlias -replace '\s','_').json"

if ($Restore) {
    Write-Step "Restoring $InterfaceAlias to DHCP"
    Remove-NetIPAddress -InterfaceAlias $InterfaceAlias -AddressFamily IPv4 -Confirm:$false -ErrorAction SilentlyContinue
    Remove-NetRoute -InterfaceAlias $InterfaceAlias -AddressFamily IPv4 -Confirm:$false -ErrorAction SilentlyContinue
    Set-NetIPInterface -InterfaceAlias $InterfaceAlias -Dhcp Enabled
    Set-DnsClientServerAddress -InterfaceAlias $InterfaceAlias -ResetServerAddresses
    Write-Ok 'Adapter reset to DHCP.'
}
else {
    if (-not $IPAddress -or -not $Gateway -or -not $DNS) {
        throw 'Provide -IPAddress, -Gateway and -DNS (or use -Restore).'
    }
    New-Item -ItemType Directory -Force -Path (Split-Path $backupFile) | Out-Null
    Write-Step "Backing up current config for $InterfaceAlias to $backupFile"
    Get-NetIPConfiguration -InterfaceAlias $InterfaceAlias | ConvertTo-Json -Depth 5 | Out-File $backupFile
    Write-Ok 'Backup saved (informational; use -Restore to actually revert to DHCP).'

    Write-Step "Applying static IP to $InterfaceAlias"
    Remove-NetIPAddress -InterfaceAlias $InterfaceAlias -AddressFamily IPv4 -Confirm:$false -ErrorAction SilentlyContinue
    New-NetIPAddress -InterfaceAlias $InterfaceAlias -IPAddress $IPAddress -PrefixLength $PrefixLength -DefaultGateway $Gateway
    Set-DnsClientServerAddress -InterfaceAlias $InterfaceAlias -ServerAddresses $DNS
    Write-Ok 'Static IP applied.'
}

Write-Step 'Verifying'
Get-NetIPConfiguration -InterfaceAlias $InterfaceAlias | Format-List
ipconfig /all | Select-String $InterfaceAlias -Context 0,15
