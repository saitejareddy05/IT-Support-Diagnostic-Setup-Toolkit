<#
.SYNOPSIS
    Part 3 (Networking) - show and optionally set the Workgroup name.

.DESCRIPTION
    Lab machines with no domain controller use Workgroup mode: each PC keeps its own
    local user accounts and there is no central login server. A Domain (Active
    Directory) uses one central server (the domain controller) that issues logins,
    group policy and permissions for every joined machine. Workgroup does not scale
    past a handful of PCs; Domain is what real offices use.

.PARAMETER WorkgroupName
    Optional: set a new workgroup name (requires a reboot to take effect).

.EXAMPLE
    .\P3-WorkgroupInfo.ps1
.EXAMPLE
    .\P3-WorkgroupInfo.ps1 -WorkgroupName TEAM-IT
#>
[CmdletBinding()]
param([string]$WorkgroupName)
. "$PSScriptRoot\_Common.ps1"

Write-Step 'Current membership'
$cs = Get-CimInstance Win32_ComputerSystem
[pscustomobject]@{
    ComputerName = $cs.Name
    PartOfDomain = $cs.PartOfDomain
    Workgroup    = $cs.Workgroup
    Domain       = $cs.Domain
} | Format-List

if ($WorkgroupName) {
    Assert-Admin
    Write-Step "Changing workgroup to $WorkgroupName (reboot required after)"
    Add-Computer -WorkGroupName $WorkgroupName
    Write-Ok 'Changed. Reboot to fully apply, then re-run this script without -WorkgroupName to verify.'
}

Write-Output ''
Write-Output 'WORKGROUP vs DOMAIN, in short:'
Write-Output '  Workgroup: peer-to-peer. Each PC has its own local accounts/passwords.'
Write-Output '             Fine for a handful of home/lab machines. No central policy.'
Write-Output '  Domain   : client-server. A domain controller (Active Directory) centrally'
Write-Output '             manages accounts, passwords and Group Policy for every joined PC.'
Write-Output '             Standard for business networks; requires a domain controller,'
Write-Output '             which this lab does not have, so we use Workgroup only.'
