<#
.SYNOPSIS
    Part 5 (App Lifecycle) - silently install an app, verify, then fully uninstall
    and check for leftovers.

.DESCRIPTION
    Works with any .msi (always supports /qn) or .exe installer (silent switch varies
    by vendor - common ones are listed below). Snapshots the registry Uninstall keys
    and Program Files before and after so you can PROVE nothing was left behind.

    Common silent switches by installer type:
      MSI                : msiexec /i "app.msi" /qn /norestart
      Inno Setup         : app-setup.exe /VERYSILENT /NORESTART
      NSIS               : app-setup.exe /S
      InstallShield      : app-setup.exe /s /v"/qn"
    Check the vendor's docs or run "app-setup.exe /?" to be sure - switches are NOT standardised.

.PARAMETER InstallerPath
    Path to the .msi or .exe installer.

.PARAMETER SilentArgs
    Silent-install arguments (see table above). For .msi this is ignored; /qn is used.

.PARAMETER Phase
    'Install', 'Verify' or 'Uninstall'. Run them in that order, in separate calls.

.EXAMPLE
    .\P5-SilentInstall.ps1 -InstallerPath C:\Downloads\7z-setup.exe -SilentArgs '/S' -Phase Install
.EXAMPLE
    .\P5-SilentInstall.ps1 -Phase Verify -DisplayNameFilter '7-Zip'
.EXAMPLE
    .\P5-SilentInstall.ps1 -Phase Uninstall -DisplayNameFilter '7-Zip'
#>
[CmdletBinding()]
param(
    [string]$InstallerPath,
    [string]$SilentArgs,
    [Parameter(Mandatory)] [ValidateSet('Install', 'Verify', 'Uninstall')] [string]$Phase,
    [string]$DisplayNameFilter
)
. "$PSScriptRoot\_Common.ps1"
Assert-Admin

$snapDir = Join-Path $PSScriptRoot '..\reports'
New-Item -ItemType Directory -Force -Path $snapDir | Out-Null

switch ($Phase) {
    'Install' {
        if (-not $InstallerPath) { throw '-InstallerPath is required for -Phase Install' }
        Write-Step 'Snapshotting installed apps BEFORE install'
        Get-InstalledApps | Export-Csv (Join-Path $snapDir 'apps_before.csv') -NoTypeInformation

        Write-Step "Installing $InstallerPath silently"
        if ($InstallerPath -match '\.msi$') {
            Start-Process msiexec.exe -ArgumentList "/i `"$InstallerPath`" /qn /norestart" -Wait -PassThru |
                Select-Object -ExpandProperty ExitCode | ForEach-Object { Write-Output "Exit code: $_" }
        }
        else {
            if (-not $SilentArgs) { throw 'Provide -SilentArgs for an .exe installer (see script help for common switches).' }
            $p = Start-Process -FilePath $InstallerPath -ArgumentList $SilentArgs -Wait -PassThru
            Write-Output "Exit code: $($p.ExitCode)"
        }
        Write-Ok 'Install command finished. Run -Phase Verify next.'
    }

    'Verify' {
        Write-Step 'Snapshotting installed apps AFTER install'
        Get-InstalledApps | Export-Csv (Join-Path $snapDir 'apps_after.csv') -NoTypeInformation

        $before = @()
        $beforeFile = Join-Path $snapDir 'apps_before.csv'
        if (Test-Path $beforeFile) { $before = Import-Csv $beforeFile }
        $after = Import-Csv (Join-Path $snapDir 'apps_after.csv')

        Write-Step 'New entries since the "before" snapshot'
        Compare-Object -ReferenceObject $before -DifferenceObject $after -Property DisplayName |
            Where-Object SideIndicator -eq '=>' | Format-Table -AutoSize

        if ($DisplayNameFilter) {
            Write-Step "Entries matching '$DisplayNameFilter'"
            $after | Where-Object DisplayName -like "*$DisplayNameFilter*" | Format-List
        }
    }

    'Uninstall' {
        if (-not $DisplayNameFilter) { throw '-DisplayNameFilter is required for -Phase Uninstall, e.g. "7-Zip"' }
        $app = Get-InstalledApps | Where-Object DisplayName -like "*$DisplayNameFilter*" | Select-Object -First 1
        if (-not $app) { throw "No installed app matches '$DisplayNameFilter'." }
        Write-Step "Uninstalling: $($app.DisplayName)"

        $cmd = if ($app.QuietUninstallString) { $app.QuietUninstallString } else { $app.UninstallString }
        Write-Output "Uninstall command: $cmd"
        if ($cmd -match 'msiexec') {
            $guid = ($cmd | Select-String -Pattern '\{[0-9A-Fa-f-]+\}').Matches[0].Value
            Start-Process msiexec.exe -ArgumentList "/x $guid /qn /norestart" -Wait
        }
        else {
            # Best effort: most uninstallers accept /S or /VERYSILENT; if this hangs waiting on
            # a GUI, close it and re-run the vendor's own quiet uninstall switch instead.
            Start-Process cmd.exe -ArgumentList "/c `"$cmd`" /S" -Wait
        }
        Write-Ok 'Uninstall command finished.'

        Write-Step 'Checking for leftovers'
        Write-Output 'Registry uninstall entry still present?'
        Get-InstalledApps | Where-Object DisplayName -like "*$DisplayNameFilter*" |
            ForEach-Object { Write-Warn "STILL PRESENT: $($_.DisplayName)" }
        if (-not (Get-InstalledApps | Where-Object DisplayName -like "*$DisplayNameFilter*")) {
            Write-Ok 'No matching registry entry remains.'
        }

        Write-Output ''
        Write-Output 'Leftover folders to check by hand (paths vary per app):'
        Write-Output "  Get-ChildItem 'C:\Program Files','C:\Program Files (x86)' -Filter '*$DisplayNameFilter*'"
        Write-Output "  Get-ChildItem `"`$env:APPDATA`",`"`$env:LOCALAPPDATA`" -Filter '*$DisplayNameFilter*'"
    }
}
