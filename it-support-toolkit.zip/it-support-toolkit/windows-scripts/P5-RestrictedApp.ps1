<#
.SYNOPSIS
    Part 5 (App Lifecycle) - restrict an app's folder access using NTFS permissions,
    and confirm the restriction works.

.DESCRIPTION
    Denies a target user Read access to a folder (e.g. an app's data folder) and shows
    how to prove the block works: attempt access as that user with runas, which should
    fail with Access Denied.

.PARAMETER FolderPath
    Folder to restrict.

.PARAMETER UserName
    Local user to restrict (use the standard account created in P2-NewUser.ps1).

.EXAMPLE
    .\P5-RestrictedApp.ps1 -FolderPath "C:\Program Files\ExampleApp" -UserName jdoe
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string]$FolderPath,
    [Parameter(Mandatory)] [string]$UserName
)
. "$PSScriptRoot\_Common.ps1"
Assert-Admin

if (-not (Test-Path $FolderPath)) { throw "Folder not found: $FolderPath" }

Write-Step "Denying $UserName access to $FolderPath"
$acl = Get-Acl $FolderPath
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
    $UserName, 'ReadAndExecute', 'ContainerInherit,ObjectInherit', 'None', 'Deny')
$acl.AddAccessRule($rule)
Set-Acl -Path $FolderPath -AclObject $acl
Write-Ok 'Deny rule added. (Explicit Deny always overrides any Allow, from any group.)'

Write-Step 'Verifying the ACL'
(Get-Acl $FolderPath).Access | Where-Object IdentityReference -like "*$UserName*" | Format-Table -AutoSize

Write-Output ''
Write-Output "To PROVE the block works, open a new console AS $UserName and try to list the folder:"
Write-Output "  runas /user:$env:COMPUTERNAME\$UserName cmd"
Write-Output "  # then inside that new window:"
Write-Output "  dir `"$FolderPath`""
Write-Output '  # expected: "Access is denied."'
Write-Output ''
Write-Output "To undo later:"
Write-Output "  `$acl = Get-Acl '$FolderPath'; `$acl.Access | Where IdentityReference -like '*$UserName*' | %{ `$acl.RemoveAccessRule(`$_) }; Set-Acl '$FolderPath' `$acl"
