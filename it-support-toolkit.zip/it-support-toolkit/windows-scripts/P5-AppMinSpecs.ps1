<#
.SYNOPSIS
    Part 5 (App Lifecycle) - compare an app's minimum system requirements against this
    machine's specs from the Part 1 diagnostic report.

.DESCRIPTION
    Reads RAM/CPU/disk from this machine (same source SysDiag.ps1 uses) and prints them
    next to the minimum requirements you supply (look these up on the app's official
    site first) so you can compare pass/fail by eye before installing.

.EXAMPLE
    .\P5-AppMinSpecs.ps1 -AppName "Example App" -MinRamGB 8 -MinDiskGB 20 -MinOSBuild 19045
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string]$AppName,
    [double]$MinRamGB,
    [double]$MinDiskGB,
    [int]$MinOSBuild
)
. "$PSScriptRoot\_Common.ps1"

$cs  = Get-CimInstance Win32_ComputerSystem
$os  = Get-CimInstance Win32_OperatingSystem
$sys = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'"

$ramGB   = [math]::Round($cs.TotalPhysicalMemory / 1GB, 1)
$freeGB  = [math]::Round($sys.FreeSpace / 1GB, 1)
$build   = [int]$os.BuildNumber

Write-Step "Requirements check: $AppName"
[pscustomobject]@{
    Check         = 'RAM (GB)'
    ThisMachine   = $ramGB
    Minimum       = $MinRamGB
    Pass          = ($ramGB -ge $MinRamGB)
},
[pscustomobject]@{
    Check         = 'Free disk space (GB)'
    ThisMachine   = $freeGB
    Minimum       = $MinDiskGB
    Pass          = ($freeGB -ge $MinDiskGB)
},
[pscustomobject]@{
    Check         = 'OS build'
    ThisMachine   = $build
    Minimum       = $MinOSBuild
    Pass          = ($build -ge $MinOSBuild)
} | Format-Table -AutoSize

Write-Output 'Look up minimum requirements on the vendor''s official download/system-requirements page before installing.'
