<#
.SYNOPSIS
    Part 2 (Onboarding) - partition practice using a virtual disk (VHD), not a real one.

.DESCRIPTION
    Shrinking and re-partitioning a REAL disk on your only machine is how people lose
    data by accident. This script creates a small virtual hard disk (.vhdx) file,
    attaches it as if it were a real disk, and lets you practice: create a partition,
    format it NTFS, then (separately) practice shrinking a volume on it. It documents
    each step's diskpart/PowerShell equivalent so you understand what Disk Management
    does under the hood. If you genuinely want to test on a real VM's disk instead,
    the exact same New-Partition/Format-Volume/Resize-Partition commands apply - just
    point them at the VM's disk number from Get-Disk.

.PARAMETER VhdPath
    Where to create the practice virtual disk. Default: C:\DiagLab\PracticeDisk.vhdx

.PARAMETER SizeGB
    Size of the practice disk. Default 5 GB.

.EXAMPLE
    .\P2-PartitionTestDisk.ps1
#>
[CmdletBinding()]
param(
    [string]$VhdPath = 'C:\DiagLab\PracticeDisk.vhdx',
    [int]$SizeGB = 5
)
. "$PSScriptRoot\_Common.ps1"
Assert-Admin

New-Item -ItemType Directory -Force -Path (Split-Path $VhdPath) | Out-Null

if (Test-Path $VhdPath) { Write-Warn "$VhdPath already exists - remove it first if you want a clean run."; return }
$useHyperV = [bool](Get-Command New-VHD -ErrorAction SilentlyContinue)

if ($useHyperV) {
    Write-Step "1) Creating a $SizeGB GB virtual disk at $VhdPath (Hyper-V cmdlets)"
    New-VHD -Path $VhdPath -SizeBytes ($SizeGB * 1GB) -Dynamic | Out-Null
    Write-Ok 'Virtual disk file created.'

    Write-Step '2) Mounting (attaching) it - it now appears like a real disk in Disk Management'
    Mount-VHD -Path $VhdPath
    Start-Sleep -Seconds 1
    $disk = (Get-VHD -Path $VhdPath).DiskNumber
    Write-Ok "Attached as disk $disk. Open diskmgmt.msc now to watch it appear."

    Write-Step '3) Initializing the disk (GPT) - same as right-click disk > Initialize Disk'
    Initialize-Disk -Number $disk -PartitionStyle GPT -ErrorAction SilentlyContinue

    Write-Step '4) Creating a partition on the whole disk and assigning a drive letter'
    $partition   = New-Partition -DiskNumber $disk -UseMaximumSize -AssignDriveLetter
    $driveLetter = $partition.DriveLetter
    Write-Ok "Partition created as ${driveLetter}:"

    Write-Step '5) Formatting NTFS - same as right-click volume > Format'
    Format-Volume -DriveLetter $driveLetter -FileSystem NTFS -NewFileSystemLabel 'PRACTICE' -Confirm:$false | Out-Null
    Write-Ok "Formatted ${driveLetter}: as NTFS."
}
else {
    Write-Warn 'Hyper-V cmdlets not found (normal on Windows Home). Using diskpart instead - same result.'
    $sizeMB = $SizeGB * 1024
    $dp = Join-Path $env:TEMP 'toolkit_diskpart.txt'
    @(
        "create vdisk file=`"$VhdPath`" maximum=$sizeMB type=expandable",
        "attach vdisk",
        "convert gpt",
        "create partition primary",
        "format fs=ntfs quick label=PRACTICE",
        "assign"
    ) | Set-Content -Path $dp -Encoding ASCII
    Write-Step '1-5) Running diskpart script (create vdisk, attach, convert gpt, create partition, format NTFS, assign)'
    Get-Content $dp | ForEach-Object { Write-Output "   diskpart> $_" }
    diskpart /s $dp
    Remove-Item $dp -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    $vol = Get-Volume | Where-Object FileSystemLabel -eq 'PRACTICE' | Select-Object -First 1
    if (-not $vol) { throw 'Practice volume not found after diskpart. Open diskmgmt.msc to inspect.' }
    $driveLetter = $vol.DriveLetter
    $disk = (Get-Partition -DriveLetter $driveLetter).DiskNumber
    Write-Ok "Practice volume is ${driveLetter}: on disk $disk."
}

Write-Step '6) Verifying'
Get-Partition -DiskNumber $disk | Select-Object PartitionNumber, DriveLetter, Size, Type | Format-Table -AutoSize
Get-Volume -DriveLetter $driveLetter | Select-Object DriveLetter, FileSystemLabel, FileSystem, SizeRemaining, Size

Write-Output ''
Write-Output '--- SHRINK PRACTICE (run separately, once the above worked) ---'
Write-Output "  Get-PartitionSupportedSize -DriveLetter $driveLetter"
Write-Output "  Resize-Partition -DriveLetter $driveLetter -Size <smaller size from above, in bytes>"
Write-Output '  # then create a second partition in the freed space:'
Write-Output "  New-Partition -DiskNumber $disk -UseMaximumSize -AssignDriveLetter | Format-Volume -FileSystem NTFS -Confirm:`$false"
Write-Output ''
Write-Output 'diskpart equivalent, for comparison (run diskpart, then at its DISKPART> prompt):'
Write-Output "  select disk $disk"
Write-Output '  list partition'
Write-Output '  select partition 1'
Write-Output '  shrink desired=1000        REM shrink by 1000 MB'
Write-Output '  create partition primary'
Write-Output '  format fs=ntfs quick'
Write-Output '  assign'
Write-Output ''
Write-Output 'CLEANUP when finished practicing (detach + delete the practice disk):'
Write-Output "  Hyper-V:  Dismount-VHD -Path '$VhdPath'"
Write-Output "  diskpart: select vdisk file='$VhdPath'  then  detach vdisk"
Write-Output "  Remove-Item '$VhdPath'"
