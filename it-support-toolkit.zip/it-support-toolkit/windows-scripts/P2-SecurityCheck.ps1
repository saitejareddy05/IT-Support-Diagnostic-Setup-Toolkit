<#
.SYNOPSIS
    Part 2 (Onboarding) - verify Defender scan schedule and BitLocker status from the CLI.

.DESCRIPTION
    Companion to the Control Panel step: after you enable BitLocker (Control Panel >
    System and Security > BitLocker Drive Encryption) and/or set a Defender scan
    schedule (Windows Security > Virus & threat protection > Scan options), run this
    to verify the setting stuck, from the command line.

.EXAMPLE
    .\P2-SecurityCheck.ps1
#>
. "$PSScriptRoot\_Common.ps1"
Assert-Admin

Write-Step 'Windows Defender scheduled scan settings'
try {
    Get-MpPreference | Select-Object ScanScheduleDay, ScanScheduleTime, ScanParameters,
        DisableRealtimeMonitoring | Format-List
    Write-Output 'ScanScheduleDay: 0=Every day, 1=Sunday ... 7=Saturday, 8=Never'
    Write-Output 'ScanParameters : 1=Quick scan, 2=Full scan'
}
catch { Write-Warn 'Get-MpPreference not available (Defender may be off or replaced by 3rd-party AV).' }

Write-Step 'BitLocker status (all volumes)'
try {
    manage-bde -status
}
catch { Write-Warn 'manage-bde not available on this edition (BitLocker needs Pro/Enterprise/Education).' }

Write-Step 'BitLocker status (PowerShell cmdlet, easier to read)'
try { Get-BitLockerVolume | Select-Object MountPoint, VolumeStatus, EncryptionPercentage, ProtectionStatus | Format-Table -AutoSize }
catch { Write-Warn 'Get-BitLockerVolume not available.' }
