<#
.SYNOPSIS
    Part 3 (Networking) - toggle network discovery and check visibility settings.

.DESCRIPTION
    Sets the network category (Private = discoverable by default, Public = hidden by
    default) and shows the underlying firewall rule group that actually implements
    "Network Discovery". Confirm visibility by checking another device's Network
    folder / `net view`.

.PARAMETER Category
    'Private' (discoverable) or 'Public' (not discoverable, more locked down).

.EXAMPLE
    .\P3-NetworkDiscovery.ps1 -Category Private
#>
[CmdletBinding()]
param([Parameter(Mandatory)] [ValidateSet('Private', 'Public')] [string]$Category)
. "$PSScriptRoot\_Common.ps1"
Assert-Admin

Write-Step 'Current network profile(s)'
Get-NetConnectionProfile | Select-Object InterfaceAlias, NetworkCategory | Format-Table -AutoSize

Write-Step "Setting all connected profiles to $Category"
Get-NetConnectionProfile | ForEach-Object {
    Set-NetConnectionProfile -InterfaceIndex $_.InterfaceIndex -NetworkCategory $Category
}
Write-Ok "Profile(s) set to $Category."

Write-Step 'Network Discovery firewall rule group status'
Get-NetFirewallRule -DisplayGroup 'Network Discovery' |
    Select-Object DisplayName, Enabled, Direction, Profile | Format-Table -AutoSize

Write-Output ''
Write-Output 'Verify from ANOTHER DEVICE on the same network:'
Write-Output "  net view \\$env:COMPUTERNAME          (or open its Network folder in Explorer)"
Write-Output "Verify locally that discovery is on:"
Write-Output '  Get-NetFirewallRule -DisplayGroup "Network Discovery" | Where Enabled -eq True'
