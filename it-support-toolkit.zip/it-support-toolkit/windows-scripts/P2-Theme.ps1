<#
.SYNOPSIS
    Part 2 (Onboarding) - toggle dark/light theme via the registry, to compare with Settings.

.DESCRIPTION
    Learning exercise: change the theme by hand first in
    Settings > Personalization > Colors, note what changed, then run this script to make
    the SAME change from PowerShell and confirm they land on the same registry values.

.PARAMETER Mode
    'Dark' or 'Light'.

.EXAMPLE
    .\P2-Theme.ps1 -Mode Dark
#>
[CmdletBinding()]
param([Parameter(Mandatory)] [ValidateSet('Dark', 'Light')] [string]$Mode)
. "$PSScriptRoot\_Common.ps1"

$key = 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize'
New-Item -Path $key -Force | Out-Null
$value = if ($Mode -eq 'Dark') { 0 } else { 1 }

Write-Step "Setting apps + system theme to $Mode (registry)"
Set-ItemProperty -Path $key -Name 'AppsUseLightTheme'    -Value $value -Type DWord
Set-ItemProperty -Path $key -Name 'SystemUsesLightTheme' -Value $value -Type DWord
Write-Ok 'Registry updated. Explorer/taskbar may need a moment (or Alt+Tab) to repaint.'

Write-Step 'Verifying'
Get-ItemProperty -Path $key | Select-Object AppsUseLightTheme, SystemUsesLightTheme | Format-List
Write-Output 'Compare: open Settings > Personalization > Colors - "Choose your mode" should match what you just set.'
Write-Output '(0 = Dark, 1 = Light for both values.)'
