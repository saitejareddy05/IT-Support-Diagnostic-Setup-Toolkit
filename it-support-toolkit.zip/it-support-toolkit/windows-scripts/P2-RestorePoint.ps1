<#
.SYNOPSIS
    Part 2 (Onboarding) - create and verify a System Restore point from the command line.

.DESCRIPTION
    Enables System Restore on the system drive if needed, creates a restore point,
    then lists existing restore points so you can confirm it was created.
    System Restore is off by default on many Windows 10/11 Home installs.

.EXAMPLE
    .\P2-RestorePoint.ps1 -Description "Before onboarding new employee workstation"
#>
[CmdletBinding()]
param([string]$Description = "Toolkit checkpoint $(Get-Date -Format 'yyyy-MM-dd HH:mm')")
. "$PSScriptRoot\_Common.ps1"
Assert-Admin

Write-Step "Enabling System Restore on $env:SystemDrive (harmless if already on)"
Enable-ComputerRestore -Drive $env:SystemDrive
Write-Ok 'System Restore is enabled.'

Write-Step 'Windows limits restore points to one per 24h by default; this may be skipped if one was made recently.'
Checkpoint-Computer -Description $Description -RestorePointType 'MODIFY_SETTINGS'

Write-Step 'Verifying: listing existing restore points'
Get-ComputerRestorePoint | Select-Object SequenceNumber, Description, CreationTime, RestorePointType |
    Sort-Object CreationTime -Descending | Format-Table -AutoSize

Write-Output ''
Write-Output 'To actually roll back to a point (only if you really need to; this reboots the machine):'
Write-Output '    Restore-Computer -RestorePoint <SequenceNumber>'
