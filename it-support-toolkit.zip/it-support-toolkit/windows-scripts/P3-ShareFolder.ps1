<#
.SYNOPSIS
    Part 3 (Networking) - share a folder over the network and set NTFS + share permissions.

.DESCRIPTION
    Creates the folder if needed, shares it with New-SmbShare, and grants matching NTFS
    permissions. Two permission layers control access: the SHARE permission (network
    door) and the NTFS permission (permission on the actual folder); the more
    restrictive of the two always wins.

.PARAMETER Path
    Local folder to share.

.PARAMETER ShareName
    Network share name (what \\COMPUTERNAME\ShareName resolves to).

.PARAMETER ReadOnly
    Grant read-only access instead of full/change access.

.EXAMPLE
    .\P3-ShareFolder.ps1 -Path C:\ShareTest -ShareName TeamDocs
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string]$Path,
    [Parameter(Mandatory)] [string]$ShareName,
    [switch]$ReadOnly
)
. "$PSScriptRoot\_Common.ps1"
Assert-Admin

New-Item -ItemType Directory -Force -Path $Path | Out-Null

Write-Step "Sharing $Path as \\$env:COMPUTERNAME\$ShareName"
Remove-SmbShare -Name $ShareName -Force -ErrorAction SilentlyContinue
$access = if ($ReadOnly) { 'Read' } else { 'Change' }
if ($ReadOnly) {
    New-SmbShare -Name $ShareName -Path $Path -FullAccess 'Administrators' -ReadAccess 'Everyone' | Out-Null
} else {
    New-SmbShare -Name $ShareName -Path $Path -FullAccess 'Administrators' -ChangeAccess 'Everyone' | Out-Null
}
Write-Ok "Share created (network permission: $access for Everyone; tighten this to a real group in production)."

Write-Step 'Matching NTFS permission on the folder'
$ntfsRight = if ($ReadOnly) { 'ReadAndExecute' } else { 'Modify' }
$acl = Get-Acl $Path
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule('Everyone', $ntfsRight, 'ContainerInherit,ObjectInherit', 'None', 'Allow')
$acl.AddAccessRule($rule)
Set-Acl -Path $Path -AclObject $acl
Write-Ok "NTFS permission set: Everyone = $ntfsRight."

Write-Step 'Verifying'
Get-SmbShare -Name $ShareName | Format-List Name, Path, Description
Get-SmbShareAccess -Name $ShareName | Format-Table -AutoSize
(Get-Acl $Path).Access | Select-Object IdentityReference, FileSystemRights, AccessControlType | Format-Table -AutoSize

Write-Output ''
Write-Output "From ANOTHER DEVICE, confirm access:"
Write-Output "  \\$env:COMPUTERNAME\$ShareName        (type this into a File Explorer address bar)"
Write-Output "or:"
Write-Output "  net view \\$env:COMPUTERNAME"
