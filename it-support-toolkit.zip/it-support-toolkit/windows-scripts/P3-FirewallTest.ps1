<#
.SYNOPSIS
    Part 3 (Networking) - block a TCP port with Windows Firewall and prove it's blocked.

.DESCRIPTION
    Creates an inbound block rule for the given port, tests connectivity to it with
    Test-NetConnection before and after, then optionally removes the rule again.
    Test FROM ANOTHER MACHINE for a true test (localhost traffic can bypass the
    firewall); this script also shows the localhost result for convenience.

.PARAMETER Port
    TCP port to block, e.g. 8080. A quick way to have something listening on it for the
    test: Start-Job { python -m http.server 8080 } or 'ncat -l 8080'.

.PARAMETER RemoteHost
    Host to test FROM if run on another machine pointed at this one. Default: localhost.

.PARAMETER RuleName
    Firewall rule name. Default: Toolkit-Block-<Port>

.PARAMETER Remove
    Remove the block rule instead of creating it.

.EXAMPLE
    .\P3-FirewallTest.ps1 -Port 8080
.EXAMPLE
    .\P3-FirewallTest.ps1 -Port 8080 -Remove
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [int]$Port,
    [string]$RemoteHost = 'localhost',
    [string]$RuleName,
    [switch]$Remove
)
. "$PSScriptRoot\_Common.ps1"
Assert-Admin
if (-not $RuleName) { $RuleName = "Toolkit-Block-$Port" }

if ($Remove) {
    Write-Step "Removing firewall rule '$RuleName'"
    Remove-NetFirewallRule -DisplayName $RuleName -ErrorAction SilentlyContinue
    Write-Ok 'Rule removed.'
}
else {
    Write-Step "BEFORE: testing TCP $RemoteHost`:$Port"
    Test-NetConnection -ComputerName $RemoteHost -Port $Port | Select-Object ComputerName, RemotePort, TcpTestSucceeded

    Write-Step "Creating inbound block rule '$RuleName' for TCP port $Port"
    New-NetFirewallRule -DisplayName $RuleName -Direction Inbound -Protocol TCP `
        -LocalPort $Port -Action Block | Out-Null
    Write-Ok 'Rule created.'

    Write-Step "AFTER: testing TCP $RemoteHost`:$Port again (TcpTestSucceeded should now be False)"
    Test-NetConnection -ComputerName $RemoteHost -Port $Port | Select-Object ComputerName, RemotePort, TcpTestSucceeded

    Write-Output ''
    Write-Output "For a real test, run this FROM ANOTHER DEVICE on the network:"
    Write-Output "  Test-NetConnection -ComputerName <this machine's IP> -Port $Port"
    Write-Output "or (older tool, needs 'telnet client' feature enabled):"
    Write-Output "  telnet <this machine's IP> $Port"
    Write-Output ''
    Write-Output "Clean up later with:  .\P3-FirewallTest.ps1 -Port $Port -Remove"
}
