<#
.SYNOPSIS
    Part 2 (Onboarding) - configure the Windows Update pause policy.

.DESCRIPTION
    Sets the registry values Windows Update reads to pause updates until a given date,
    then reads them back to verify, and shows how to clear the pause. These are the
    same values Settings > Windows Update > "Pause updates" writes; this script edits
    them directly so you can do it without opening the GUI.

.PARAMETER Days
    Number of days to pause updates for (max 35, which is Windows' own limit).

.PARAMETER Clear
    Remove the pause instead of setting one.

.EXAMPLE
    .\P2-UpdatePause.ps1 -Days 7
.EXAMPLE
    .\P2-UpdatePause.ps1 -Clear
#>
[CmdletBinding()]
param(
    [ValidateRange(1, 35)] [int]$Days = 7,
    [switch]$Clear
)
. "$PSScriptRoot\_Common.ps1"
Assert-Admin

$key = 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings'
New-Item -Path $key -Force | Out-Null

if ($Clear) {
    Write-Step 'Clearing Windows Update pause'
    Remove-ItemProperty -Path $key -Name 'PauseUpdatesExpiryTime' -ErrorAction SilentlyContinue
    Remove-ItemProperty -Path $key -Name 'PauseFeatureUpdatesEndTime' -ErrorAction SilentlyContinue
    Remove-ItemProperty -Path $key -Name 'PauseQualityUpdatesEndTime' -ErrorAction SilentlyContinue
    Write-Ok 'Pause cleared. Restart the "Windows Update" service (wuauserv) or reboot for it to fully re-check.'
}
else {
    $until = (Get-Date).AddDays($Days).ToString('yyyy-MM-ddTHH:mm:ssZ')
    Write-Step "Pausing Windows Update until $until"
    Set-ItemProperty -Path $key -Name 'PauseUpdatesExpiryTime'      -Value $until
    Set-ItemProperty -Path $key -Name 'PauseFeatureUpdatesEndTime'  -Value $until
    Set-ItemProperty -Path $key -Name 'PauseQualityUpdatesEndTime'  -Value $until
    Write-Ok 'Registry values set.'
}

Write-Step 'Verifying (registry values)'
Get-ItemProperty -Path $key | Select-Object PauseUpdatesExpiryTime, PauseFeatureUpdatesEndTime, PauseQualityUpdatesEndTime |
    Format-List
Write-Output 'GUI cross-check: Settings > Windows Update - it should show "Paused until <date>" (or no pause banner if cleared).'
