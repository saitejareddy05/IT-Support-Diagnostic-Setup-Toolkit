<#
.SYNOPSIS
    Part 2 (Onboarding) - create a local standard (non-admin) user account.

.DESCRIPTION
    Creates a local user with New-LocalUser, adds it to the Users group only (NOT
    Administrators), then verifies. Also shows the older net user equivalent as a
    comment so you can compare both approaches.

.PARAMETER UserName
    Account name to create, e.g. jdoe

.PARAMETER FullName
    Display name, e.g. "Jane Doe"

.EXAMPLE
    .\P2-NewUser.ps1 -UserName jdoe -FullName "Jane Doe"
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string]$UserName,
    [string]$FullName = $UserName
)
. "$PSScriptRoot\_Common.ps1"
Assert-Admin

Write-Step "Creating local standard user '$UserName'"
$securePw = Read-Host -AsSecureString "Set a password for $UserName"

New-LocalUser -Name $UserName -FullName $FullName -Password $securePw `
    -AccountNeverExpires -PasswordNeverExpires:$false -Description 'Created by P2-NewUser.ps1'
Write-Ok "Account created."

# Standard (non-admin) accounts are members of "Users", not "Administrators".
Add-LocalGroupMember -Group 'Users' -Member $UserName -ErrorAction SilentlyContinue
Write-Ok "Added to the local Users group (standard rights, not admin)."

Write-Step 'Verifying'
Get-LocalUser -Name $UserName | Select-Object Name, FullName, Enabled, PasswordRequired | Format-List
Write-Output "Group memberships for ${UserName}:"
Get-LocalGroup | Where-Object {
    (Get-LocalGroupMember $_.Name -ErrorAction SilentlyContinue).Name -contains "$env:COMPUTERNAME\$UserName"
} | Select-Object -ExpandProperty Name

<#
Equivalent using the older net user / net localgroup commands, for comparison:

    net user jdoe P@ssword123! /add /fullname:"Jane Doe"
    net localgroup Users jdoe /add
    net user jdoe                     REM verify

net user works on any Windows edition; New-LocalUser needs the Microsoft.PowerShell.LocalAccounts
module, which is missing on Windows on a domain controller and on Server Core "Nano" installs.
#>
