# _Common.ps1
# Shared helpers. Every P*-*.ps1 script loads this with:  . "$PSScriptRoot\_Common.ps1"
# Keep this file ASCII-only: Windows PowerShell 5.1 reads BOM-less files as ANSI.

function Assert-Admin {
    $p = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
    if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'This script needs an elevated PowerShell: right-click PowerShell > Run as administrator.'
    }
}

function Write-Step([string]$Message) { Write-Host "`n[*] $Message" -ForegroundColor Cyan }
function Write-Ok  ([string]$Message) { Write-Host "    [OK]   $Message" -ForegroundColor Green }
function Write-Warn([string]$Message) { Write-Host "    [WARN] $Message" -ForegroundColor Yellow }
function Write-Fail([string]$Message) { Write-Host "    [FAIL] $Message" -ForegroundColor Red }

function Confirm-Action([string]$Message) {
    $answer = Read-Host "$Message  Type YES to continue"
    return ($answer -ceq 'YES')
}

# Installed desktop apps from the three registry uninstall locations:
#   HKLM 64-bit apps, HKLM\WOW6432Node 32-bit apps, HKCU per-user apps.
# (Avoid Win32_Product: it is slow and can trigger MSI repair runs.)
function Get-InstalledApps {
    $paths = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
             'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
             'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    Get-ItemProperty -Path $paths -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName } |
        Select-Object DisplayName, DisplayVersion, Publisher, InstallLocation,
                      UninstallString, QuietUninstallString, PSChildName
}
