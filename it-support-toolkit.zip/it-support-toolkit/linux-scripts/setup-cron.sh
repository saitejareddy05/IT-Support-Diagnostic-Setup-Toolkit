#!/usr/bin/env bash
# setup-cron.sh — Part 4: schedule disk-check.sh to run every hour via cron.
# Usage: ./setup-cron.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DISK_CHECK="$SCRIPT_DIR/disk-check.sh"
CRON_LOG="$HOME/diag-lab/cron-disk-check.log"
mkdir -p "$(dirname "$CRON_LOG")"
chmod +x "$DISK_CHECK"

# WSL note: cron does not start automatically with Windows. Either:
#   1) run:  sudo service cron start   (once per WSL session), or
#   2) add "sudo service cron start" to your ~/.bashrc, or
#   3) enable it to auto-start via /etc/wsl.conf's [boot] systemd=true (WSL2, newer builds)
# Check it's running with: service cron status

CRON_LINE="0 * * * * $DISK_CHECK >> $CRON_LOG 2>&1"
( crontab -l 2>/dev/null | grep -vF "$DISK_CHECK" ; echo "$CRON_LINE" ) | crontab -

echo "Cron job installed. Current crontab:"
crontab -l

echo -e "\nRuns disk-check.sh at the top of every hour. Output logged to: $CRON_LOG"
echo "If this is WSL, make sure the cron service is running:  sudo service cron status"
