#!/usr/bin/env bash
# network-check.sh — Part 4: ip a, ping, ss -tulpn, curl connectivity test.
# Usage: ./network-check.sh [url-to-test]
set -uo pipefail   # no -e: individual checks are allowed to fail without killing the script

URL="${1:-https://example.com}"

echo "=== Interfaces and IP addresses (ip a) ==="
ip a

echo -e "\n=== Ping test (3 packets to 1.1.1.1) ==="
ping -c 3 1.1.1.1 || echo "Ping failed (blocked ICMP, or no connectivity)."

echo -e "\n=== Open/listening ports (ss -tulpn) ==="
echo "-t=TCP -u=UDP -l=listening only -p=show process -n=numeric ports (needs sudo for process names)"
if command -v sudo >/dev/null 2>&1; then
    sudo ss -tulpn || ss -tulpn
else
    ss -tulpn
fi

echo -e "\n=== curl connectivity test: $URL ==="
curl -sS -o /dev/null -w "HTTP status: %{http_code}\nTotal time: %{time_total}s\n" "$URL" || echo "curl failed to reach $URL"

echo -e "\nDone."
