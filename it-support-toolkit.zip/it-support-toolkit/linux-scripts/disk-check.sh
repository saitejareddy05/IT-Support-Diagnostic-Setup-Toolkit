#!/usr/bin/env bash
# disk-check.sh — Part 4: disk usage check, top 5 largest files/folders, flag >80% full.
# Usage: ./disk-check.sh [path-to-scan]   (default: $HOME)
set -euo pipefail

SCAN_PATH="${1:-$HOME}"
THRESHOLD=80
LOG_FILE="$HOME/diag-lab/disk-check.log"
mkdir -p "$(dirname "$LOG_FILE")"

echo "=== Disk usage check: $(date '+%Y-%m-%d %H:%M:%S') ===" | tee -a "$LOG_FILE"

echo -e "\n--- Filesystem usage (df -h) ---" | tee -a "$LOG_FILE"
df -h | tee -a "$LOG_FILE"

echo -e "\n--- Checking each mounted filesystem against ${THRESHOLD}% ---" | tee -a "$LOG_FILE"
# Parse df output; skip pseudo filesystems (tmpfs etc. use --exclude-type below).
df -h --output=pcent,target -x tmpfs -x devtmpfs -x overlay 2>/dev/null | tail -n +2 | while read -r pcent target; do
    pct="${pcent%\%}"
    if [ "$pct" -ge "$THRESHOLD" ]; then
        echo "WARNING: $target is ${pcent} full (threshold: ${THRESHOLD}%)" | tee -a "$LOG_FILE"
    fi
done

echo -e "\n--- Top 5 largest directories under $SCAN_PATH ---" | tee -a "$LOG_FILE"
# du: -x stays on one filesystem, -h human sizes. 2>/dev/null hides "Permission denied" noise.
du -xh "$SCAN_PATH" 2>/dev/null | sort -rh | head -n 5 | tee -a "$LOG_FILE"

echo -e "\n--- Top 5 largest individual files under $SCAN_PATH ---" | tee -a "$LOG_FILE"
find "$SCAN_PATH" -xdev -type f -printf '%s\t%p\n' 2>/dev/null | sort -rn | head -n 5 | \
    awk -F'\t' '{ printf "%.1f MB\t%s\n", $1/1048576, $2 }' | tee -a "$LOG_FILE"

echo -e "\nDone. Full log: $LOG_FILE"
