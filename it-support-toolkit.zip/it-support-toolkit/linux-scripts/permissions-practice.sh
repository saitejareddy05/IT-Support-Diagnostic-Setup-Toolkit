#!/usr/bin/env bash
# permissions-practice.sh — Part 4: chmod 750 practice, explained.
# Usage: ./permissions-practice.sh
# Creates a test user (t_owner) so you can actually SWITCH USER and see permissions
# bite, instead of just reading numbers. Needs sudo.
set -euo pipefail

FILE="$HOME/diag-lab/permtest.txt"
mkdir -p "$(dirname "$FILE")"
echo "secret owner-only-by-default content" > "$FILE"

echo "--- Setting chmod 750 on $FILE ---"
chmod 750 "$FILE"
ls -la "$FILE"

echo -e "\n750 breakdown:"
echo "  7 (owner)  = rwx = read, write, execute"
echo "  5 (group)  = r-x = read, execute, NOT write"
echo "  0 (others) = --- = nothing at all"
echo
echo "For a plain text file, 'execute' isn't meaningful (it's not a program),"
echo "so in practice this means: owner can read+edit, group members can only read, everyone else: nothing."

CUR_USER="$(whoami)"
echo -e "\nCurrent owner: $CUR_USER"
echo "Current group: $(stat -c '%G' "$FILE" 2>/dev/null || stat -f '%Sg' "$FILE")"

if command -v sudo >/dev/null 2>&1 && sudo -n true 2>/dev/null; then
    echo -e "\n--- Testing as another user (requires sudo, creates temp user t_owner) ---"
    if ! id t_owner &>/dev/null; then
        sudo useradd -m t_owner
    fi
    echo "As t_owner (not owner, not in the file's group) trying to read the file:"
    sudo -u t_owner cat "$FILE" 2>&1 || echo "  -> Permission denied, as expected (others = ---)."
else
    echo -e "\n(Skipping the switch-user test: needs passwordless sudo. Run manually:)"
    echo "  sudo useradd -m t_owner"
    echo "  sudo -u t_owner cat '$FILE'      # should fail: Permission denied"
fi

echo -e "\n--- Try these yourself to see each level's effect ---"
echo "  chmod 700 '$FILE'   # only the owner can do anything"
echo "  chmod 770 '$FILE'   # owner + group can read/write, others nothing"
echo "  chmod 777 '$FILE'   # everyone can read/write (avoid this in real use)"
echo "  sudo -u t_owner cat '$FILE'   # re-test after each change above"

echo -e "\nCleanup when done: sudo userdel -r t_owner"
