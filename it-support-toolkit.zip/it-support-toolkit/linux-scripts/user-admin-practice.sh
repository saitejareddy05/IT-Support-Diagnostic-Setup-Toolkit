#!/usr/bin/env bash
# user-admin-practice.sh — Part 4: create a Linux user, add to a group, grant sudo.
# Usage: sudo ./user-admin-practice.sh <username>
set -euo pipefail

if [ "$EUID" -ne 0 ]; then
    echo "Run this with sudo: sudo $0 <username>" >&2
    exit 1
fi

USERNAME="${1:?Usage: sudo $0 <username>}"

echo "--- Creating user $USERNAME (with home directory) ---"
useradd -m -s /bin/bash "$USERNAME"
passwd "$USERNAME"

echo -e "\n--- Adding $USERNAME to the 'sudo' group (Debian/Ubuntu; use 'wheel' on RHEL/Fedora) ---"
SUDO_GROUP="sudo"
command -v usermod >/dev/null || { echo "usermod not found" >&2; exit 1; }
if ! getent group sudo >/dev/null; then SUDO_GROUP="wheel"; fi
usermod -aG "$SUDO_GROUP" "$USERNAME"

echo -e "\n--- Verifying ---"
echo "id output:"
id "$USERNAME"
echo -e "\nGroups (should include $SUDO_GROUP):"
groups "$USERNAME"

echo -e "\n--- To verify as that user yourself, switch to them and check whoami/sudo ---"
echo "  su - $USERNAME"
echo "  whoami        # should print: $USERNAME"
echo "  sudo whoami   # after entering their password, should print: root"

echo -e "\nCleanup when done: sudo userdel -r $USERNAME"
