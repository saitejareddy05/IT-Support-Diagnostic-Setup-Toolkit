#!/usr/bin/env bash
# backup.sh — Part 4: tar.gz backup of a folder with a timestamped filename.
# Usage: ./backup.sh <source-dir> [dest-dir]   (default dest: ~/diag-lab/backups)
set -euo pipefail

SRC="${1:?Usage: $0 <source-dir> [dest-dir]}"
DEST="${2:-$HOME/diag-lab/backups}"

if [ ! -d "$SRC" ]; then
    echo "Error: source directory '$SRC' does not exist." >&2
    exit 1
fi

mkdir -p "$DEST"
STAMP="$(date +%Y%m%d_%H%M%S)"
BASENAME="$(basename "$SRC")"
ARCHIVE="$DEST/${BASENAME}_${STAMP}.tar.gz"

echo "Backing up '$SRC' -> '$ARCHIVE'"
# -C moves into the parent dir first so the archive doesn't embed the full absolute path.
tar -czf "$ARCHIVE" -C "$(dirname "$SRC")" "$BASENAME"

echo "Verifying archive integrity (tar -tzf lists contents without extracting)..."
tar -tzf "$ARCHIVE" > /dev/null && echo "OK: archive is readable."

SIZE=$(du -h "$ARCHIVE" | cut -f1)
echo "Backup complete: $ARCHIVE ($SIZE)"

echo -e "\nTo restore:"
echo "  tar -xzf '$ARCHIVE' -C /path/to/restore/into"
