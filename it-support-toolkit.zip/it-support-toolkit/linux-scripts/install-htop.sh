#!/usr/bin/env bash
# install-htop.sh — Part 4: install and briefly demo htop.
# Usage: ./install-htop.sh
set -euo pipefail

if command -v htop >/dev/null 2>&1; then
    echo "htop is already installed: $(command -v htop)"
else
    echo "Installing htop..."
    if command -v apt >/dev/null 2>&1; then
        sudo apt update && sudo apt install -y htop
    elif command -v dnf >/dev/null 2>&1; then
        sudo dnf install -y htop
    elif command -v pacman >/dev/null 2>&1; then
        sudo pacman -Sy --noconfirm htop
    else
        echo "No known package manager found (apt/dnf/pacman). Install htop manually." >&2
        exit 1
    fi
fi

echo -e "\nhtop installed: $(htop --version | head -n1)"
echo "Run 'htop' now to explore it interactively. Quick reference:"
echo "  F5        toggle tree view (see process parent/child relationships)"
echo "  F6        sort by a column (e.g. MEM%, CPU%)"
echo "  F9        kill the selected process"
echo "  q         quit"
