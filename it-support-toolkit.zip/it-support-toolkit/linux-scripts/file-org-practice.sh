#!/usr/bin/env bash
# file-org-practice.sh — Part 4: build a deliberately messy folder, then organize it
# using find / cp -r / mv / ls -la, printing each command's effect as you go.
# Usage: ./file-org-practice.sh
set -euo pipefail

LAB="$HOME/diag-lab/messy-folder"
rm -rf "$LAB"
mkdir -p "$LAB"/{inbox,junk}
cd "$LAB"

echo "--- Creating a messy test folder at $LAB ---"
touch inbox/report.docx inbox/photo1.jpg inbox/photo2.png inbox/notes.txt \
      inbox/invoice.pdf inbox/script.sh junk/old.tmp junk/cache.log
mkdir -p inbox/nested/deep
touch inbox/nested/deep/buried.txt

echo -e "\n--- ls -la (before) ---"
ls -la inbox

echo -e "\n--- find: locate every .txt file, anywhere under inbox (including nested) ---"
find inbox -type f -name '*.txt'

echo -e "\n--- Organizing: create category folders ---"
mkdir -p sorted/{images,documents,scripts,other}

echo -e "\n--- cp -r: copy nested folder structure into sorted/other (keeps originals) ---"
cp -r inbox/nested sorted/other/

echo -e "\n--- mv: move files by type into their category folders ---"
mv inbox/*.jpg inbox/*.png sorted/images/      2>/dev/null || true
mv inbox/*.docx inbox/*.pdf inbox/*.txt sorted/documents/ 2>/dev/null || true
mv inbox/*.sh sorted/scripts/                  2>/dev/null || true
mv junk/* sorted/other/                        2>/dev/null || true

echo -e "\n--- ls -la (after), each category ---"
for d in sorted/*/; do
    echo "== $d =="
    ls -la "$d"
done

echo -e "\nDone. Explore $LAB yourself and try your own find/cp/mv combinations."
