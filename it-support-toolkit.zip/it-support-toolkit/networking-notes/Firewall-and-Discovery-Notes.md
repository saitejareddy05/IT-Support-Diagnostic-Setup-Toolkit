# Firewall + network discovery — what I found

Record your own results here after running `P3-FirewallTest.ps1` and
`P3-NetworkDiscovery.ps1`:

- Port tested: ___
- `Test-NetConnection` result before blocking: `TcpTestSucceeded = ___`
- `Test-NetConnection` result after blocking:  `TcpTestSucceeded = ___`
- Tested from another device? Y/N — result: ___
- Network category set: Private / Public
- Visible in another device's Network folder after setting Private? Y/N
- Visible after switching to Public? Y/N
