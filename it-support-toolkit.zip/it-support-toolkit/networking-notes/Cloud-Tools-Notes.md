# Part 6 — Cloud-based productivity tools: hands-on notes

Do these two exercises yourself, then fill in what you observed. This is deliberately
a template, not filled-in results — the point is your own observation.

## 1. Cloud folder sync + conflict resolution (OneDrive or Google Drive)

1. Install the sync client, sign in, let it create its local sync folder.
2. Create a test file in the sync folder, e.g. `conflict-test.txt`, let it sync.
3. Edit it from a **second** location (a phone app, the web UI, or a second PC) while
   **offline on the first machine** or fast enough to race the sync — the goal is two
   different edits landing before they can merge.
4. Reconnect / wait for sync and observe what happens.

Record:
- Tool used: ___
- What happened to the file: kept both as separate files ("filename (1).txt" /
  "conflicted copy") — or one silently overwrote the other? ___
- Which edit won, if only one survived: ___

## 2. Sharing permissions: view-only vs edit

1. Create a doc in a cloud office suite (Google Docs or Office Online).
2. Share it with a second account (or an incognito/private browser session) as
   **Viewer** — try to type into it. Record what happens.
3. Change the share to **Editor** — try again.

Record:
- As Viewer, could you: select text? ___ copy it? ___ type/edit? ___ comment? ___
- As Editor, could you: type/edit? ___ see the other person's cursor live? ___

## 3. Storage-as-a-Service vs Software-as-a-Service

Try at least two different "ways of using cloud computing" and compare:

| | Example used | What it actually is |
|---|---|---|
| Storage-as-a-Service | e.g. OneDrive/Google Drive/Dropbox | Cloud is just a file-syncing hard drive: it stores and syncs your files, and any editing still happens in a local app on your device (or in a separate SaaS app). |
| Software-as-a-Service | e.g. Google Docs/Office Online | The **application itself** runs in the cloud too, not just the file. Multiple people can edit the same live document simultaneously; there's no separate "your copy vs my copy" to sync. |

**In your own words, what's the core difference?**
_(write your answer here after trying both)_
