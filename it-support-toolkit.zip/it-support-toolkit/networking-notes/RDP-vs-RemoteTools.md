# RDP vs SSH vs TeamViewer/AnyDesk — hands-on notes

## 1. Set up RDP (Remote Desktop Protocol) to a VM

On the **target** VM (the one you'll connect *to*):
```powershell
# Enable Remote Desktop
Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -Value 0
Enable-NetFirewallRule -DisplayGroup 'Remote Desktop'

# Confirm which users can RDP in (must be an admin or added to Remote Desktop Users)
Get-LocalGroupMember 'Remote Desktop Users'
```
On the **client**, run `mstsc` (Remote Desktop Connection) and enter the target's IP or hostname.

Verify from the client:
```powershell
Test-NetConnection <target-ip> -Port 3389
```

## 2. Set up a remote-tool connection (TeamViewer / AnyDesk) or SSH

- **TeamViewer/AnyDesk:** install on both machines, run it on the host, share the
  generated ID + one-time password with the connecting side, enter them on the client.
- **SSH** (built into Windows 10 1809+/11): on the target,
  ```powershell
  Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0
  Start-Service sshd
  Set-Service -Name sshd -StartupType Automatic
  Enable-NetFirewallRule -Name OpenSSH-Server-In-TCP
  ```
  From the client: `ssh username@target-ip`

## 3. Differences — what I actually observed

| | RDP | TeamViewer / AnyDesk | SSH |
|---|---|---|---|
| What you get | Full graphical desktop | Full graphical desktop | Command-line only (no GUI, unless you tunnel one) |
| Works across the open internet without setup? | No — needs port-forwarding/VPN, or is blocked by most ISPs/firewalls by default | Yes — relays through the vendor's cloud, works through NAT with no config | No — same as RDP, needs the port reachable or a tunnel |
| Needs an account with a vendor? | No | Yes (their relay service) | No |
| Typical use | IT managing a machine on the same network/VPN | Ad-hoc support to a home user's PC | Server administration, scripting, automation |
| Security model | Windows login + optional Network Level Authentication | Vendor-issued session ID + password, traffic relayed through their servers | Key-based or password auth, direct encrypted channel |
| Bandwidth | Higher (streams the whole desktop) | Higher (streams the whole desktop) | Very low (just text, unless tunneling) |

**Takeaway:** RDP and TeamViewer/AnyDesk both give a full remote desktop, but RDP expects
you to already have network-level access (LAN/VPN/forwarded port) while the third-party
tools solve the "get through NAT/firewalls with zero config" problem by relaying through
their own servers — at the cost of trusting a third party with the session. SSH trades the
GUI for a lightweight, scriptable, more easily secured channel — the default choice for
managing servers.
